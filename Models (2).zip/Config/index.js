/**
 * Created by Shumi on 13/01/18.
 */

module.exports = {

    APP_CONSTANTS: require('./appConstants'),
    responseMessages: require('./responseMessages'),
    // awsS3Config: require('./awsS3Config'),
    emailConfig: require('./emailConfig'),
    development: require('./development'),
};