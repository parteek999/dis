/**
 * Created by Shumi on 21/3/20.
 */




module.exports = {
    Admin: require('./Admin'),
    Branch: require('./Branch'),
    User: require('./User'),
    Stock: require('./Stock'),
    Common: require('./Common'),
    Captain: require('./Captain'),
    Order:require('./Order'),


};